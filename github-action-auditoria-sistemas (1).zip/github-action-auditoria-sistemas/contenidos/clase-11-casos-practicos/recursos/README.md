# Recursos sugeridos - Clase 11 - Casos prácticos de Auditoría de TI

- Plantillas de trabajo
- Casos de estudio
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
