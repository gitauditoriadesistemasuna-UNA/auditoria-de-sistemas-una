# Clase 07 - Gestión de Riesgos de TI

**Curso:** EIF543 Auditoría de Sistemas  
**Periodo:** II Ciclo Lectivo 2026  
**Modalidad del curso:** Virtual  
**Repositorio:** `gitauditoriadesistemasuna-UNA/clase-07-riesgos-ti`  
**Semana o unidad:** Semana de gestión de riesgos  
**Modalidad sugerida:** Sincrónica / caso práctico

## Propósito

Identificación, evaluación y tratamiento de riesgos de TI mediante metodologías y matrices.

## Relación con el programa oficial

Este material forma parte de la biblioteca digital del curso **EIF543 Auditoría de Sistemas**. Se organiza a partir de los contenidos del programa 2026, que incluyen conceptos generales de auditoría, gestión de riesgos de TI, control interno, marcos de referencia, cumplimiento normativo, evidencia, papeles de trabajo, metodología de auditoría, comunicación de resultados y casos prácticos.

## Contenidos de la clase

- Definición de riesgo
- Definición de control
- Riesgo inherente
- Riesgo residual
- Riesgo de detección
- Ciclo de vida del riesgo
- ISO 31000
- Escenarios de riesgo COBIT 5
- Método tradicional de riesgos
- Medidas de tratamiento

## Actividades sugeridas

- Construcción de matriz de riesgos
- Análisis de controles preventivos, detectivos, correctivos y compensatorios
- Caso práctico Periculum

## Producto o evidencia esperada

- Matriz de riesgo inherente
- Matriz de riesgo residual
- Propuesta de tratamiento de riesgos

## Recursos didácticos

- Plantillas de riesgos
- Caso práctico
- Videos del ciclo de vida del riesgo
- Aula Virtual

## Guía de trabajo de la clase

### Antes de la clase

- Revisar el contenido base indicado en este repositorio.
- Anotar dudas conceptuales.
- Revisar el Aula Virtual por instrucciones o materiales adicionales.

### Durante la clase

- Participar en la discusión o actividad asignada.
- Relacionar los conceptos con situaciones reales de auditoría de TI.
- Construir evidencias de trabajo: notas, mapas, matrices, cuestionarios o borradores.

### Después de la clase

- Completar el producto solicitado.
- Revisar ortografía, redacción y referencias APA 7 cuando corresponda.
- Entregar en la plataforma indicada por la persona docente.

## Uso ético de IA generativa

La IA generativa puede utilizarse como apoyo para aclarar conceptos, estructurar ideas o buscar posibles fuentes de consulta. Cuando se utilice, el estudiantado debe conservar evidencia de los prompts y respuestas usadas, revisar críticamente el resultado y citarlo cuando corresponda según APA 7.

## Recomendación para el estudiantado

Trabaje con criterio profesional: todo hallazgo, conclusión o recomendación de auditoría debe estar sustentado en evidencia suficiente, pertinente y documentada.
