# Recursos sugeridos - Clase 07 - Gestión de Riesgos de TI

- Plantillas de riesgos
- Caso práctico
- Videos del ciclo de vida del riesgo
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
