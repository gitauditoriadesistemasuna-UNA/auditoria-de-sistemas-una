# Recursos sugeridos - Clase 08 - Cumplimiento normativo en Auditoría de TI

- Normas nacionales
- Normas internacionales
- Sitios oficiales
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
