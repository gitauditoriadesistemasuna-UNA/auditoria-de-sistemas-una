# Clase 08 - Cumplimiento normativo en Auditoría de TI

**Curso:** EIF543 Auditoría de Sistemas  
**Periodo:** II Ciclo Lectivo 2026  
**Modalidad del curso:** Virtual  
**Repositorio:** `gitauditoriadesistemasuna-UNA/clase-08-cumplimiento-normativo`  
**Semana o unidad:** Semana de normativa nacional e internacional  
**Modalidad sugerida:** Sincrónica / investigación

## Propósito

Revisión de criterios legales, normativos y de mejores prácticas aplicables a auditoría de sistemas.

## Relación con el programa oficial

Este material forma parte de la biblioteca digital del curso **EIF543 Auditoría de Sistemas**. Se organiza a partir de los contenidos del programa 2026, que incluyen conceptos generales de auditoría, gestión de riesgos de TI, control interno, marcos de referencia, cumplimiento normativo, evidencia, papeles de trabajo, metodología de auditoría, comunicación de resultados y casos prácticos.

## Contenidos de la clase

- Ley General de Control Interno
- Ley de Delitos Informáticos
- Ley de Contratación Administrativa y su reglamento
- Ley de Protección de Datos Personales
- Ley de Firma Digital
- Ley de Derechos de Autor
- Normas técnicas para la gestión de TI
- Normas de Control Interno para el Sector Público
- COBIT 2019
- ISO 38500
- NIST
- ISO 27000
- ITIL v4
- ISO 20000
- ISO 22301
- TOGAF

## Actividades sugeridas

- Investigación de marcos normativos
- Mapa comparativo de normas
- Identificación de criterios de auditoría

## Producto o evidencia esperada

- Cuadro de cumplimiento normativo
- Mapa de criterios
- Referencia APA 7 de fuentes consultadas

## Recursos didácticos

- Normas nacionales
- Normas internacionales
- Sitios oficiales
- Aula Virtual

## Guía de trabajo de la clase

### Antes de la clase

- Revisar el contenido base indicado en este repositorio.
- Anotar dudas conceptuales.
- Revisar el Aula Virtual por instrucciones o materiales adicionales.

### Durante la clase

- Participar en la discusión o actividad asignada.
- Relacionar los conceptos con situaciones reales de auditoría de TI.
- Construir evidencias de trabajo: notas, mapas, matrices, cuestionarios o borradores.

### Después de la clase

- Completar el producto solicitado.
- Revisar ortografía, redacción y referencias APA 7 cuando corresponda.
- Entregar en la plataforma indicada por la persona docente.

## Uso ético de IA generativa

La IA generativa puede utilizarse como apoyo para aclarar conceptos, estructurar ideas o buscar posibles fuentes de consulta. Cuando se utilice, el estudiantado debe conservar evidencia de los prompts y respuestas usadas, revisar críticamente el resultado y citarlo cuando corresponda según APA 7.

## Recomendación para el estudiantado

Trabaje con criterio profesional: todo hallazgo, conclusión o recomendación de auditoría debe estar sustentado en evidencia suficiente, pertinente y documentada.
