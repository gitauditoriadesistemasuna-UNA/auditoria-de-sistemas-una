# Recursos sugeridos - Clase 03 - Tipos de Auditoría

- Programa del curso
- Lecturas de auditoría
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
