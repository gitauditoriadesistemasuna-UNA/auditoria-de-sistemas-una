# Clase 01 - Bienvenida a Auditoría de Sistemas

**Curso:** EIF543 Auditoría de Sistemas  
**Periodo:** II Ciclo Lectivo 2026  
**Modalidad del curso:** Virtual  
**Repositorio:** `gitauditoriadesistemasuna-UNA/clase-01-bienvenida-auditoria-sistemas`  
**Semana o unidad:** Semana inicial / apertura del curso  
**Modalidad sugerida:** Sincrónica

## Propósito

Repositorio de apertura para presentar el curso, la dinámica de trabajo, el uso de GitHub y la organización de los materiales.

## Relación con el programa oficial

Este material forma parte de la biblioteca digital del curso **EIF543 Auditoría de Sistemas**. Se organiza a partir de los contenidos del programa 2026, que incluyen conceptos generales de auditoría, gestión de riesgos de TI, control interno, marcos de referencia, cumplimiento normativo, evidencia, papeles de trabajo, metodología de auditoría, comunicación de resultados y casos prácticos.

## Contenidos de la clase

- Presentación del curso
- Lectura del programa
- Organización de repositorios
- Uso del Aula Virtual y GitHub
- Normas de entrega y formato PDF/Markdown
- Uso ético de IA generativa

## Actividades sugeridas

- Presentación personal y expectativas del curso
- Revisión guiada del programa de curso
- Explicación de la biblioteca digital de contenidos
- Foro de consulta inicial

## Producto o evidencia esperada

- Confirmación de acceso a los repositorios
- Participación en foro de bienvenida
- Registro de dudas iniciales

## Recursos didácticos

- Programa del curso 2026-IIC-EIF543
- Aula Virtual
- GitHub
- Zoom o Teams

## Guía de trabajo de la clase

### Antes de la clase

- Revisar el contenido base indicado en este repositorio.
- Anotar dudas conceptuales.
- Revisar el Aula Virtual por instrucciones o materiales adicionales.

### Durante la clase

- Participar en la discusión o actividad asignada.
- Relacionar los conceptos con situaciones reales de auditoría de TI.
- Construir evidencias de trabajo: notas, mapas, matrices, cuestionarios o borradores.

### Después de la clase

- Completar el producto solicitado.
- Revisar ortografía, redacción y referencias APA 7 cuando corresponda.
- Entregar en la plataforma indicada por la persona docente.

## Uso ético de IA generativa

La IA generativa puede utilizarse como apoyo para aclarar conceptos, estructurar ideas o buscar posibles fuentes de consulta. Cuando se utilice, el estudiantado debe conservar evidencia de los prompts y respuestas usadas, revisar críticamente el resultado y citarlo cuando corresponda según APA 7.

## Recomendación para el estudiantado

Trabaje con criterio profesional: todo hallazgo, conclusión o recomendación de auditoría debe estar sustentado en evidencia suficiente, pertinente y documentada.
