# Recursos sugeridos - Clase 01 - Bienvenida a Auditoría de Sistemas

- Programa del curso 2026-IIC-EIF543
- Aula Virtual
- GitHub
- Zoom o Teams

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
