# Recursos sugeridos - Clase 00 - Bienvenida

- Programa de curso
- Aula Virtual
- Correo institucional

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
