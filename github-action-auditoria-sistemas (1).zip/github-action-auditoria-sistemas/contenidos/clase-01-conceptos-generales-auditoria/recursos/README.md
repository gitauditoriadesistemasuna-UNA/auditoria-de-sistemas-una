# Recursos sugeridos - Clase 01 - Conceptos generales de Auditoría

- Presentación del docente
- Aula Virtual
- Video del tema Ciberseguridad

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
