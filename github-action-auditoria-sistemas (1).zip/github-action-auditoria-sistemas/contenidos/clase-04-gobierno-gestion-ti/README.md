# Clase 04 - Gobierno y Gestión de TI

**Curso:** EIF543 Auditoría de Sistemas  
**Periodo:** II Ciclo Lectivo 2026  
**Modalidad del curso:** Virtual  
**Repositorio:** `gitauditoriadesistemasuna-UNA/clase-04-gobierno-gestion-ti`  
**Semana o unidad:** Semana de gobierno, gestión y marcos de referencia  
**Modalidad sugerida:** Sincrónica / investigación

## Propósito

Relación entre gobierno de TI, gestión de TI, control y auditoría.

## Relación con el programa oficial

Este material forma parte de la biblioteca digital del curso **EIF543 Auditoría de Sistemas**. Se organiza a partir de los contenidos del programa 2026, que incluyen conceptos generales de auditoría, gestión de riesgos de TI, control interno, marcos de referencia, cumplimiento normativo, evidencia, papeles de trabajo, metodología de auditoría, comunicación de resultados y casos prácticos.

## Contenidos de la clase

- Gobierno de TI
- Gestión de TI
- Diferencias entre gobernar y gestionar
- COBIT 2019
- ISO 38500
- ITIL v4
- ISO 20000
- TOGAF
- Scrum
- Prince2
- PMBOK
- Sanas prácticas

## Actividades sugeridas

- Presentación del tema
- Caso práctico Toyota
- Investigación sobre marcos de referencia
- Comparación de marcos

## Producto o evidencia esperada

- Cuadro comparativo de marcos
- Exposición grupal
- Síntesis ejecutiva

## Recursos didácticos

- COBIT 2019
- ISO 38500
- ITIL
- PMBOK
- Aula Virtual

## Guía de trabajo de la clase

### Antes de la clase

- Revisar el contenido base indicado en este repositorio.
- Anotar dudas conceptuales.
- Revisar el Aula Virtual por instrucciones o materiales adicionales.

### Durante la clase

- Participar en la discusión o actividad asignada.
- Relacionar los conceptos con situaciones reales de auditoría de TI.
- Construir evidencias de trabajo: notas, mapas, matrices, cuestionarios o borradores.

### Después de la clase

- Completar el producto solicitado.
- Revisar ortografía, redacción y referencias APA 7 cuando corresponda.
- Entregar en la plataforma indicada por la persona docente.

## Uso ético de IA generativa

La IA generativa puede utilizarse como apoyo para aclarar conceptos, estructurar ideas o buscar posibles fuentes de consulta. Cuando se utilice, el estudiantado debe conservar evidencia de los prompts y respuestas usadas, revisar críticamente el resultado y citarlo cuando corresponda según APA 7.

## Recomendación para el estudiantado

Trabaje con criterio profesional: todo hallazgo, conclusión o recomendación de auditoría debe estar sustentado en evidencia suficiente, pertinente y documentada.
