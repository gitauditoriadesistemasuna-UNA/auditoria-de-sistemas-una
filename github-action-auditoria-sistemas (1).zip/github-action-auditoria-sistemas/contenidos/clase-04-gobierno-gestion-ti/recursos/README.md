# Recursos sugeridos - Clase 04 - Gobierno y Gestión de TI

- COBIT 2019
- ISO 38500
- ITIL
- PMBOK
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
