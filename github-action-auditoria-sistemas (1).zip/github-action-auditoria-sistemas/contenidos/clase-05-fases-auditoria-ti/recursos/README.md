# Recursos sugeridos - Clase 05 - Fases de la Auditoría de TI

- Programa de auditoría
- Plantillas
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
