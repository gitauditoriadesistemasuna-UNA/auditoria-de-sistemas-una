# Actividad de aprendizaje - Clase 06 - Control Interno

## Objetivo

Aplicar los contenidos de la clase mediante una actividad práctica relacionada con auditoría de sistemas y tecnologías de información.

## Instrucciones

1. Revise el archivo `README.md` del repositorio.
2. Identifique los conceptos principales de la clase.
3. Elabore el producto indicado para esta unidad.
4. Utilice fuentes confiables cuando la actividad requiera investigación.
5. Entregue el producto en el Aula Virtual o medio indicado por la persona docente.

## Producto esperado

- Infografía
- Cuestionario de control interno
- Informe de control interno

## Criterios mínimos de calidad

- Claridad conceptual.
- Coherencia entre objetivo, evidencia y conclusión.
- Uso correcto de vocabulario de auditoría de TI.
- Evidencia documentada.
- Referencias APA 7 cuando corresponda.
