# Recursos sugeridos - Clase 06 - Control Interno

- COSO III
- Ley General de Control Interno
- Plantillas
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
