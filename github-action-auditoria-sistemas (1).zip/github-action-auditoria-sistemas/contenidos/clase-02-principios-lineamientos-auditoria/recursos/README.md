# Recursos sugeridos - Clase 02 - Principios y lineamientos del ejercicio de la Auditoría

- Lecturas del curso
- Aula Virtual
- Foro de opinión

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
