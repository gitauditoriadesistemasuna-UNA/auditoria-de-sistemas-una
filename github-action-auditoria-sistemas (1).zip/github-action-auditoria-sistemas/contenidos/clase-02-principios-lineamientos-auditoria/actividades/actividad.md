# Actividad de aprendizaje - Clase 02 - Principios y lineamientos del ejercicio de la Auditoría

## Objetivo

Aplicar los contenidos de la clase mediante una actividad práctica relacionada con auditoría de sistemas y tecnologías de información.

## Instrucciones

1. Revise el archivo `README.md` del repositorio.
2. Identifique los conceptos principales de la clase.
3. Elabore el producto indicado para esta unidad.
4. Utilice fuentes confiables cuando la actividad requiera investigación.
5. Entregue el producto en el Aula Virtual o medio indicado por la persona docente.

## Producto esperado

- Ensayo breve
- Participación en foro
- Lista de principios aplicados

## Criterios mínimos de calidad

- Claridad conceptual.
- Coherencia entre objetivo, evidencia y conclusión.
- Uso correcto de vocabulario de auditoría de TI.
- Evidencia documentada.
- Referencias APA 7 cuando corresponda.
