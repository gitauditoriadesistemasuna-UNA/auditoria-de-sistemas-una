# Recursos sugeridos - Clase 09 - Evidencia y papeles de trabajo

- Plantillas en Word o Markdown
- Aula Virtual
- Casos prácticos

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
