# Recursos sugeridos - Clase 10 - Informes de Auditoría

- Plantillas de informe
- Cédula de hallazgos
- Aula Virtual

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
