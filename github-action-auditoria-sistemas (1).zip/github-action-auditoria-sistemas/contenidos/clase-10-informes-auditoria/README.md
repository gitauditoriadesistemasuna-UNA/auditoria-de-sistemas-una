# Clase 10 - Informes de Auditoría

**Curso:** EIF543 Auditoría de Sistemas  
**Periodo:** II Ciclo Lectivo 2026  
**Modalidad del curso:** Virtual  
**Repositorio:** `gitauditoriadesistemasuna-UNA/clase-10-informes-auditoria`  
**Semana o unidad:** Semana asociada a comunicación de resultados  
**Modalidad sugerida:** Sincrónica / práctica

## Propósito

Elaboración, comunicación y presentación de resultados de auditoría.

## Relación con el programa oficial

Este material forma parte de la biblioteca digital del curso **EIF543 Auditoría de Sistemas**. Se organiza a partir de los contenidos del programa 2026, que incluyen conceptos generales de auditoría, gestión de riesgos de TI, control interno, marcos de referencia, cumplimiento normativo, evidencia, papeles de trabajo, metodología de auditoría, comunicación de resultados y casos prácticos.

## Contenidos de la clase

- Informe borrador
- Presentación de resultados
- Informe final
- Resumen ejecutivo
- Redacción de hallazgos
- Recomendaciones y planes de acción

## Actividades sugeridas

- Análisis de estructura de informe
- Redacción de hallazgos con condición, criterio, causa, efecto y recomendación
- Construcción de presentación ejecutiva

## Producto o evidencia esperada

- Informe borrador
- Informe final
- Presentación de resultados

## Recursos didácticos

- Plantillas de informe
- Cédula de hallazgos
- Aula Virtual

## Guía de trabajo de la clase

### Antes de la clase

- Revisar el contenido base indicado en este repositorio.
- Anotar dudas conceptuales.
- Revisar el Aula Virtual por instrucciones o materiales adicionales.

### Durante la clase

- Participar en la discusión o actividad asignada.
- Relacionar los conceptos con situaciones reales de auditoría de TI.
- Construir evidencias de trabajo: notas, mapas, matrices, cuestionarios o borradores.

### Después de la clase

- Completar el producto solicitado.
- Revisar ortografía, redacción y referencias APA 7 cuando corresponda.
- Entregar en la plataforma indicada por la persona docente.

## Uso ético de IA generativa

La IA generativa puede utilizarse como apoyo para aclarar conceptos, estructurar ideas o buscar posibles fuentes de consulta. Cuando se utilice, el estudiantado debe conservar evidencia de los prompts y respuestas usadas, revisar críticamente el resultado y citarlo cuando corresponda según APA 7.

## Recomendación para el estudiantado

Trabaje con criterio profesional: todo hallazgo, conclusión o recomendación de auditoría debe estar sustentado en evidencia suficiente, pertinente y documentada.
