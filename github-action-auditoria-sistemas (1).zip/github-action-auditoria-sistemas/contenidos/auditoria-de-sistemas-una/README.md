# Auditoría de Sistemas UNA - Biblioteca del curso

**Curso:** EIF543 Auditoría de Sistemas  
**Periodo:** II Ciclo Lectivo 2026  
**Modalidad del curso:** Virtual  
**Repositorio:** `gitauditoriadesistemasuna-UNA/auditoria-de-sistemas-una`  
**Semana o unidad:** Repositorio general  
**Modalidad sugerida:** Virtual

## Propósito

Repositorio principal del curso EIF543 Auditoría de Sistemas, II Ciclo Lectivo 2026.

## Relación con el programa oficial

Este material forma parte de la biblioteca digital del curso **EIF543 Auditoría de Sistemas**. Se organiza a partir de los contenidos del programa 2026, que incluyen conceptos generales de auditoría, gestión de riesgos de TI, control interno, marcos de referencia, cumplimiento normativo, evidencia, papeles de trabajo, metodología de auditoría, comunicación de resultados y casos prácticos.

## Contenidos de la clase

- Descripción del curso
- Objetivos de aprendizaje
- Contenidos oficiales
- Evaluación
- Normas específicas
- Índice de clases

## Actividades sugeridas

- Consulta del programa oficial
- Navegación por los repositorios de clase
- Seguimiento de entregables

## Producto o evidencia esperada

- Mapa general de contenidos
- Bitácora de avance del curso

## Recursos didácticos

- Programa del curso
- Aula Virtual
- Repositorios de clase

## Índice de repositorios de clase

- [Clase 01 - Bienvenida a Auditoría de Sistemas](https://github.com/gitauditoriadesistemasuna-UNA/clase-01-bienvenida-auditoria-sistemas)
- [Clase 11 - Casos prácticos de Auditoría de TI](https://github.com/gitauditoriadesistemasuna-UNA/clase-11-casos-practicos)
- [Clase 10 - Informes de Auditoría](https://github.com/gitauditoriadesistemasuna-UNA/clase-10-informes-auditoria)
- [Clase 09 - Evidencia y papeles de trabajo](https://github.com/gitauditoriadesistemasuna-UNA/clase-09-evidencia-papeles-trabajo)
- [Clase 08 - Cumplimiento normativo en Auditoría de TI](https://github.com/gitauditoriadesistemasuna-UNA/clase-08-cumplimiento-normativo)
- [Clase 07 - Gestión de Riesgos de TI](https://github.com/gitauditoriadesistemasuna-UNA/clase-07-riesgos-ti)
- [Clase 06 - Control Interno](https://github.com/gitauditoriadesistemasuna-UNA/clase-06-control-interno)
- [Clase 05 - Fases de la Auditoría de TI](https://github.com/gitauditoriadesistemasuna-UNA/clase-05-fases-auditoria-ti)
- [Clase 04 - Gobierno y Gestión de TI](https://github.com/gitauditoriadesistemasuna-UNA/clase-04-gobierno-gestion-ti)
- [Clase 03 - Tipos de Auditoría](https://github.com/gitauditoriadesistemasuna-UNA/clase-03-tipos-de-auditoria)
- [Clase 02 - Principios y lineamientos del ejercicio de la Auditoría](https://github.com/gitauditoriadesistemasuna-UNA/clase-02-principios-lineamientos-auditoria)
- [Clase 01 - Conceptos generales de Auditoría](https://github.com/gitauditoriadesistemasuna-UNA/clase-01-conceptos-generales-auditoria)
- [Clase 00 - Bienvenida](https://github.com/gitauditoriadesistemasuna-UNA/clase-00-bienvenida)

## Evaluación general del curso

| Rubro | Valor |
|---|---:|
| Tareas y pruebas cortas | 15% |
| Foros de participación | 5% |
| Examen | 15% |
| Investigaciones | 40% |
| Proyecto final | 25% |
| **Total** | **100%** |

## Contenidos oficiales del curso

1. Conceptos generales de Auditoría de Tecnologías de Información.
2. Gestión de Riesgos de TI.
3. Control Interno.
4. Marcos de referencia y sanas prácticas en la Gestión de TI.
5. El proceso de la Auditoría.

## Uso ético de IA generativa

La IA generativa puede utilizarse como apoyo para aclarar conceptos, estructurar ideas o buscar posibles fuentes de consulta. Cuando se utilice, el estudiantado debe conservar evidencia de los prompts y respuestas usadas, revisar críticamente el resultado y citarlo cuando corresponda según APA 7.

## Recomendación para el estudiantado

Trabaje con criterio profesional: todo hallazgo, conclusión o recomendación de auditoría debe estar sustentado en evidencia suficiente, pertinente y documentada.
