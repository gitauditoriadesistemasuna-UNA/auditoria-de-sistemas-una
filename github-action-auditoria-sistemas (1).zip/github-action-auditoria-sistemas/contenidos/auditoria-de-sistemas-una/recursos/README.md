# Recursos sugeridos - Auditoría de Sistemas UNA - Biblioteca del curso

- Programa del curso
- Aula Virtual
- Repositorios de clase

## Nota

Los recursos específicos, enlaces, lecturas, plantillas y casos deben publicarse o confirmarse desde el Aula Virtual del curso.
