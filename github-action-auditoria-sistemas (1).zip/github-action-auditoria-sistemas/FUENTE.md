# Fuente del contenido

Material construido con base en el programa de curso **2026-IIC-EIF543 AUDITORÍA DE SISTEMAS (4).docx**.

El contenido fue reorganizado en repositorios temáticos para facilitar la publicación en GitHub y el uso por semana/clase.
