#!/usr/bin/env python3
"""Publica contenidos Markdown en múltiples repositorios de una organización.

Requiere un secreto ORG_PAT disponible como GH_TOKEN.
El token debe tener permisos para leer/crear/repositorios y escribir contenido en los repos destino.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path


def run(cmd: list[str], cwd: Path | None = None, check: bool = True) -> subprocess.CompletedProcess:
    print("$", " ".join(cmd))
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None, text=True, check=check)


def bool_arg(value: str) -> bool:
    return str(value).lower().strip() in {"1", "true", "yes", "si", "sí"}


def copy_content(src: Path, dst: Path) -> None:
    for item in src.iterdir():
        target = dst / item.name
        if item.is_dir():
            if target.exists():
                shutil.rmtree(target)
            shutil.copytree(item, target)
        else:
            shutil.copy2(item, target)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True)
    parser.add_argument("--contenidos-dir", required=True)
    parser.add_argument("--branch", default="main")
    parser.add_argument("--create-repos", default="true")
    parser.add_argument("--visibility", default="public", choices=["public", "private"])
    parser.add_argument("--dry-run", default="false")
    args = parser.parse_args()

    token = os.getenv("GH_TOKEN")
    if not token:
        print("ERROR: falta el secreto ORG_PAT expuesto como GH_TOKEN.", file=sys.stderr)
        return 2

    config_path = Path(args.config)
    contenidos_dir = Path(args.contenidos_dir)
    config = json.loads(config_path.read_text(encoding="utf-8"))
    org = config["organization"]
    create_repos = bool_arg(args.create_repos)
    dry_run = bool_arg(args.dry_run)
    branch = args.branch

    for repo in config["repositories"]:
        name = repo["name"]
        full = f"{org}/{name}"
        src = contenidos_dir / name
        if not src.exists():
            print(f"ADVERTENCIA: no existe contenido para {name}; se omite.")
            continue

        exists = run(["gh", "repo", "view", full], check=False).returncode == 0
        if not exists:
            if not create_repos:
                print(f"ERROR: {full} no existe y create-repos=false.", file=sys.stderr)
                return 3
            create_cmd = [
                "gh", "repo", "create", full,
                f"--{args.visibility}",
                "--description", repo.get("summary", "Contenido del curso EIF543 Auditoría de Sistemas"),
            ]
            if dry_run:
                print("DRY RUN: se crearía", full)
            else:
                run(create_cmd)

        with tempfile.TemporaryDirectory() as tmp:
            tmp_path = Path(tmp)
            clone_dir = tmp_path / name
            if dry_run:
                clone_dir.mkdir()
                run(["git", "init"], cwd=clone_dir)
                run(["git", "checkout", "-b", branch], cwd=clone_dir, check=False)
            else:
                run(["gh", "repo", "clone", full, str(clone_dir), "--", "--depth", "1"], check=False)
                if not clone_dir.exists() or not (clone_dir / ".git").exists():
                    clone_dir.mkdir(exist_ok=True)
                    run(["git", "init"], cwd=clone_dir)
                    run(["git", "remote", "add", "origin", f"https://github.com/{full}.git"], cwd=clone_dir)
                run(["git", "checkout", branch], cwd=clone_dir, check=False)
                run(["git", "checkout", "-b", branch], cwd=clone_dir, check=False)

            # Limpiar archivos de contenido controlado, sin borrar .git
            for item in list(clone_dir.iterdir()):
                if item.name == ".git":
                    continue
                if item.is_dir():
                    shutil.rmtree(item)
                else:
                    item.unlink()

            copy_content(src, clone_dir)
            run(["git", "add", "."], cwd=clone_dir)
            status = subprocess.run(["git", "status", "--porcelain"], cwd=str(clone_dir), text=True, capture_output=True)
            if not status.stdout.strip():
                print(f"Sin cambios en {full}")
                continue
            run(["git", "commit", "-m", "Publicar contenidos EIF543 Auditoría de Sistemas"], cwd=clone_dir)
            if dry_run:
                print(f"DRY RUN: cambios listos para {full}")
            else:
                run(["git", "push", "-u", "origin", branch], cwd=clone_dir)
                print(f"Publicado: https://github.com/{full}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
