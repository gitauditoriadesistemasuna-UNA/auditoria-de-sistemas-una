# Publicación automática de contenidos EIF543 Auditoría de Sistemas

Este repositorio controlador publica archivos Markdown en los repositorios de la organización `gitauditoriadesistemasuna-UNA`.

## Qué contiene

- `.github/workflows/publicar-contenidos.yml`: GitHub Action manual para publicar los contenidos.
- `scripts/publicar_contenidos.py`: script que crea repositorios si no existen y sube los archivos Markdown.
- `repos.json`: orden oficial de repositorios destino.
- `contenidos/<repositorio>/`: materiales Markdown de cada repositorio.

## Requisito principal

Crear un secreto del repositorio llamado `ORG_PAT`.

El token debe permitir:

- Ver la organización `gitauditoriadesistemasuna-UNA`.
- Crear repositorios dentro de la organización, si se usará la opción `crear_repositorios=true`.
- Escribir contenido en los repositorios destino.

## Uso

1. Subir estos archivos a un repositorio controlador, por ejemplo `biblioteca-eif543-auditoria-sistemas`.
2. Ir a `Actions`.
3. Ejecutar el flujo `Publicar contenidos EIF543 Auditoría de Sistemas`.
4. Elegir si se desean crear repositorios faltantes y la visibilidad `public` o `private`.
5. Ejecutar primero con `dry_run=true` para validar.
6. Ejecutar con `dry_run=false` para publicar.

## Repositorios incluidos

- `clase-01-bienvenida-auditoria-sistemas` — Clase 01 - Bienvenida a Auditoría de Sistemas
- `auditoria-de-sistemas-una` — Auditoría de Sistemas UNA - Biblioteca del curso
- `clase-11-casos-practicos` — Clase 11 - Casos prácticos de Auditoría de TI
- `clase-10-informes-auditoria` — Clase 10 - Informes de Auditoría
- `clase-09-evidencia-papeles-trabajo` — Clase 09 - Evidencia y papeles de trabajo
- `clase-08-cumplimiento-normativo` — Clase 08 - Cumplimiento normativo en Auditoría de TI
- `clase-07-riesgos-ti` — Clase 07 - Gestión de Riesgos de TI
- `clase-06-control-interno` — Clase 06 - Control Interno
- `clase-05-fases-auditoria-ti` — Clase 05 - Fases de la Auditoría de TI
- `clase-04-gobierno-gestion-ti` — Clase 04 - Gobierno y Gestión de TI
- `clase-03-tipos-de-auditoria` — Clase 03 - Tipos de Auditoría
- `clase-02-principios-lineamientos-auditoria` — Clase 02 - Principios y lineamientos del ejercicio de la Auditoría
- `clase-01-conceptos-generales-auditoria` — Clase 01 - Conceptos generales de Auditoría
- `clase-00-bienvenida` — Clase 00 - Bienvenida
